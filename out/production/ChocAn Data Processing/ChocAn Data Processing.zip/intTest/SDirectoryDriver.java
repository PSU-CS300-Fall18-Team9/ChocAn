import chocan.*;

import javax.annotation.processing.SupportedSourceVersion;

public class SDirectoryDriver {

    public static void main(String[] args)
    {
        System.out.println("Welcome to SDirectoryDriver");

        SDirectory SDir = new SDirectory();

        System.out.println(SDir);

    }
}
